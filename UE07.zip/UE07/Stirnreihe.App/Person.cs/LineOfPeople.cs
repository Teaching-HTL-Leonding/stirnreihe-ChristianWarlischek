﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stirnreihe.Data
{
    public class LineOfPeople
    {
        public Node FirstNode { get; set; }

        public void AddToFront(Person person)
        {
            Node newNode = new Node
            {
                Person = person,
                Next = FirstNode
            };
            FirstNode = newNode;
        }

        public void Clear()
        {
            FirstNode = null;
        }
    }
}
