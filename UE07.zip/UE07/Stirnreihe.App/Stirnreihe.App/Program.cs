﻿using System.Xml.Linq;
using Stirnreihe.Data;
LineOfPeople line = new LineOfPeople();

while (true)
{
    Console.WriteLine();
    Console.WriteLine("Welcome to the Stirnreihe World Record App! What do you want to do?");
    Console.WriteLine("1) Add a person to the line");
    Console.WriteLine("2) Print the line");
    Console.WriteLine("3) Clear the line");
    Console.WriteLine("4) Exit");

    Console.Write("Your choice: ");
    string choice = Console.ReadLine();

    switch (choice)
    {
        case "1":
            AddPersonToLine(line);
            break;
        case "2":
            PrintLine(line);
            break;
        case "3":
            line.Clear();
            Console.WriteLine("The line has been cleared.");
            break;
        case "4":
            Environment.Exit(0);
            break;
        default:
            Console.WriteLine("Invalid choice. Please try again.");
            break;
    }
}
static void AddPersonToLine(LineOfPeople line)
{
    Console.Write("First name: ");
    string firstName = Console.ReadLine();

    Console.Write("Last name: ");
    string lastName = Console.ReadLine();

    Console.Write("Height in cm: ");
    int height = int.Parse(Console.ReadLine());

    Person person = new Person
    {
        FirstName = firstName,
        LastName = lastName,
        Height = height
    };

    line.AddToFront(person);
    Console.WriteLine("Person added to the line.");
}

static void PrintLine(LineOfPeople line)
{
    if (line.FirstNode == null)
    {
        Console.WriteLine("The line is empty.");
        return;
    }

    Node currentNode = line.FirstNode;
    while (currentNode != null)
    {
        Console.WriteLine(currentNode.Person.ToString());
        currentNode = currentNode.Next;
    }
}

